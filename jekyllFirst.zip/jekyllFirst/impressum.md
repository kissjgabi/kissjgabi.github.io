---
layout: mydefault
title: Impressum
---
	
<h2 style="text-align: center;"><font color="#FFFFFF"><span style="background-color: #000000;">
    &nbsp; Impresszum &nbsp;
</span></font></h2>

<h2 style="text-align: center;">
    new Scienction MAGazin
</h2>

<p style="text-align: center;">	
    tudományosan szórakoztató internetes kiadvány<br>
        2020.04.01. (2016.01.01.)<br>    
	&nbsp;<br>
	<img src="assets/images/compass.png" width="333px" height="111px">
	&nbsp;<br>
	&nbsp;<br>
Vezérigazgatók: Lévai-Kiss Noémi és Ákos E. Kiss <br>
        Főszerkesztő: Kiss József Gábor<br>         
        Főszerkesztő-helyettesek: Yin Gu &amp; Yan Gu<br>         
	&nbsp;<br>
		olvasó szerkesztő: Csőke Ágnes<br>         
		kép szerkesztő: Lévai-Kiss Noémi<br>         
		tervező szerkesztő: Lévai István<br>         
	&nbsp;<br>
    Rovat vezetők:<br>
		Hírek: Kiss József Gábor<br>         
		Gazdaság: Ákos E. Kiss<br>         
		Életmód: Lévai-Kiss Noémi<br>         
		Irodalom: Csőké Ágnes<br>         
		Szórakozás: Lévai István<br>         
		Gyermek kuckó: Csőke Ágnes<br>         
	&nbsp;<br>
    Technikai munkatársak <br>
		korrektor:  Csőke Ágnes, Lévai-Kiss Noémi (design)<br>         
		fényképész: Lévai István, Ákos E.Kiss, Lévai-Kiss Noémi<br>         
		jogi szakértő: Dr. Györkő Tünde<br>         
	&nbsp;<br>
    A kiadó neve:<br>
		Global Scienction Publisher<br>         
	&nbsp;<br>
    A szerkesztőség címe és elérhetőségei:<br>
		Bercsényi utca 6. <br>         
		1111 Budapest<br>         
	&nbsp;<br>
	E-mail: b6@b6sics.hu <br>
	&nbsp;<br>
    Nyomdai előkészítés: Yin Gu<br>
        Nyomdatechnika: Yin &amp; Yan Global Digital Print ( vezérigazgató: Yan Gu )<br>         
	&nbsp;<br>
    Index, ISSN-szám: 
        <a href="http://www.oszk.hu/issn-igenyles-online-idoszaki-kiadvanyok" target="_blank">
            N/A<br>
        </a>
	&nbsp;<br>
</p>
<p style="text-align: center;">---</p>

	
<p>
	&nbsp;<br>
    <b>Terjesztési információk: </b><br>
		A tartalom a https://b6school.hu/sciention internetes címen kizárólag digitális formában 
		jelenik meg. A magazin egyes fejezetei jellegüktől és aktualitásuktól függően változó 
		időközökben frissülnek.<br>
	&nbsp;<br>
	<b>Előfizetési információk: </b><br> 
		A kiadvány kiegészítő csomagjai megrendelhetők a 
        https://b6school.hu/sciention internetes címen.<br>
    <b>Jogi nyilatkozat: </b><br> 
	a./ Szolgáltató törekedik a szolgáltatás folyamatosságának hibamentes fenntartására, 
	de nem garantálja, hogy a honlap funkcionalitása, 
	és az általa nyújtott szolgáltatás mentes a hibáktól.<br>
	b./ A honlap és annak tartalma előzetes bejelentés nélkül bármikor változhat.<br>
	c./ Szolgáltató mindent megtesz annak érdekében, hogy a honlapon elhelyezett anyagok 
	vírusmentesek illetve egyéb kártékony programoktól mentesek legyenek.<br>
	d./ Szolgáltató semmilyen felelősséget nem vállal a honlap használatából 
	vagy használhatatlanságából eredő, Felhasználót a honlap használata során ért 
	vélt vagy valós károkért, esetleges számítógép meghibásodásokért. 
	A Felhasználó saját felelősségére használja a honlapot.<br>
	e./ Szolgáltató semmilyen felelősséget nem vállal azért, ha a tartalom Felhasználó 
	rendszerében kompatibilitási, vagy egyéb hibák miatt nem elérhető. 
	Az ebből eredő, Felhasználót ért vélt, vagy valós károkért, késedelemért 
	Szolgáltató nem tehető felelőssé.<br>
	f./ Szolgáltató bármikor jogosult a jelen általános felhasználási feltételek 
	egyoldalú módosítására azzal, hogy a módosításról rövid felhívás formájában 
	a Szolgáltatás kezdőoldalán tájékoztatja a Felhasználókat. 
	Amennyiben a Felhasználó a módosítást követően a Szolgáltatás bármely részét 
	használni kezdi, az a módosítás elfogadásának minősül.<br>
	g./ Szolgáltató fenntartja magának a jogot, hogy bármilyen jogsértés, vagy 
	Felhasználó által a jelen feltételek megszegése, vagy annak gyanúja esetén 
	Felhasználót a szolgáltatásból felszólítás nélkül véglegesen kizárja.<br>
	&nbsp;<br>
	<b>Adatvédelmi nyilatkozat: </b><br>
	Szolgáltató vállalja és kötelezi magát, hogy a birtokába jutott valamennyi, 
	Felhasználóra vonatkozó adatot a mindenkori törvényes előírások betartásával 
	kezeli, azokat harmadik fél számára nem adja át, és kizárólag a szolgáltatás 
	működtetéséhez szükséges elengedhetetlen mértékben használja fel.<br>
	&nbsp;<br>
</p>
<p style="text-align: center;">---</p>

<h3 style="text-align: center;">Támogatóink:</h3>

<p style="text-align: center;">
	<b><i>
	b6.hu - sryer.com - yingu.hu - b6sics.hu - Plastdurker Kft. - OPL-Handels GmbH.
	</i></b><br>
	&nbsp;<br>
	Az alapítók:<br>
	<b><i>A finom emberek társasága (Feynman Company)</i></b><br>
	és az <br>
	<b><i>Egykő-kör (Einstein Circle)</i></b><br>

<img src="assets/images/mti_hirfelhasznalo.jpg" width="200" height="141" margin="20" border="0">
</p>

