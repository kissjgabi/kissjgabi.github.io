---
short_name: emi
name: Kiss J Gabor 
position: Intendant CEO
---
Owner of the „New Sciention” magazine. Founder of the „Einstein Circle” and the „Feynman Club”.

