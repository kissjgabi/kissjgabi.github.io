---
short_name: ghost
name: Unknown Someone
position: Ghost in the Machine
---
Someone unknown.

