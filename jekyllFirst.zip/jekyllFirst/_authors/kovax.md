---
short_name: kovax
name: Kovacs J Julia 
position: chief editor
---
Chief editor of the „New Sciention” magazine. Cofounder of the „Einstein Circle” and the „Feynman Club”.

