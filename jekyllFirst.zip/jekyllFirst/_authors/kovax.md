---
short_name: kovax
name: Kovacs J Giulia
position: chief editor
---
Chief editor of the „New Sciention” magazine. Cofounder of the „Einstein Circle” and the „Feynman Club”.

