---
tagname: diode
---
diode

