---
tagname: transistor
---
transistor

