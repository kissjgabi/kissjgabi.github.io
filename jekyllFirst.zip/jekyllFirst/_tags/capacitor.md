---
tagname: capacitor
---
capacitor
