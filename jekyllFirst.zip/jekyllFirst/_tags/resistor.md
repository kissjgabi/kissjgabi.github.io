---
tagname: resistor
---
resistor

