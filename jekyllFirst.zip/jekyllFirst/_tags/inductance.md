---
tagname: inductance
---
inductance

