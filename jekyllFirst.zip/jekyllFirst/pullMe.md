# How to? 

## 1. Local clone

### A

$ git clone https://github.com/kissjgabi/sciention.git  

### B

$ mkdir sciention  

$ cd sciention  

$ git init  

$ git remote add origin https://github.com/kissjgabi/sciention.git  

$ git pull origin master  

## 2. Jekyll

[Start with Jekyll](https://kissjgabi.github.io/kiss)  

[Download jekyllFirst.zip](https://kissjgabi.github.io/jekyllFirst.zip)

## 3. Commit

$ git add --all  

$ git commit -m "start github.com/kissjgabi/sciention"  

$ git push -u origin master  
