---
layout: post
author: emi
category: lifestyle
title: "Productivity"
tag: harmony
sitemap:
    lastmod: 2020-04-12
    priority: 0.25
    changefreq: 'none'
    exclude: 'no'
---
**Procrastination:** If you are avoiding a particular task, you are just wasting your time, and possibly other people’s time too. Set a timer for 25 minutes and use that time to get the task done. If you haven’t finished within that time period, take a 5 minute break, and set the timer again and resume working toward completing the task. This is called the Pomodoro Technique. It really works.  

**Time management:** When you are really busy and struggling to get everything done, do what every KISSer does, and write a list. Write everything you have to do, including deadlines, and then number everything in order of importance. Work your way through the list from most important to least important. Be sure to cross things off as you go along as this will give you a sense of accomplishment.  
