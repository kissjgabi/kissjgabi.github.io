---
layout: post
author: emi
category: lifestyle
title: "Relationships"
tag: harmony
sitemap:
    lastmod: 2020-04-12
    priority: 0.25
    changefreq: 'none'
    exclude: 'no'
---
**Listening:** Take what people say at face value. There is no need to waste your energy wondering what their ulterior motive is, or if they are not telling the truth about things. Keep it simple and accept their truth.  

**Talking:** Say what you mean and mean what you say. If communication is simplified both ways, you can be much happier knowing that everything is out in the open. There is no point wasting time on mind games.  
